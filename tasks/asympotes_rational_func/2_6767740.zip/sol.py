#import sympy as sp 


#def n_p_inf(q):
    #return q == sp.oo or q == -sp.oo


#def infinite(q):
    #return q == sp.oo or q == -sp.oo or q == sp.zoo or q == sp.nan


#x = sp.Symbol('x')

#f = sp.simplify(input())
f=input() # --
#denom = f.as_numer_denom()[1]
#denom_zeros = sp.solve(denom, x)
#vertical_asymptotes = []
#for i in denom_zeros:
 #   if n_p_inf(sp.limit(f, x, i, '-')) or n_p_inf(sp.limit(f, x, i, '-')):
     #   vertical_asymptotes.append(i)
#k = sp.limit(f / x, x, sp.oo)
#b = sp.limit(f - k * x, x, sp.oo)
#horizontal_asymptote = f'y = {k * x + b} ' if not (infinite(k) or infinite(b)) else '-'
#ans = [f'x = {i}' for i in sorted(vertical_asymptotes)]
#print(', '.join(ans) if ans else '-')
#print(horizontal_asymptote)
print('str') # --
print('str') # --
